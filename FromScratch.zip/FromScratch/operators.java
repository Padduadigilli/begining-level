public class operators {
    public static void main(String[] args){
        int a=10;
        a=a++;
        int b=--a;
        System.out.println("b is " + b);
        b=5;
        b-=6;
        System.out.println("b is :"+b);
    }
}
