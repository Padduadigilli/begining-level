
public class datatypes{
    public static void main(String[] args) {
        byte b=5;
        char c='a';
        short sh=10;
        int i=10;
        float f=20.0f;
        double d=5.0;
        System.out.println("result :"+((f*b)+(i%c)-(d+sh)));
        
    }
}